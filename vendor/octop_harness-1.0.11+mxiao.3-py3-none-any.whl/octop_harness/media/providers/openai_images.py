"""OpenAI Images API adapter for synchronous GPT Image generation and edits."""

from __future__ import annotations

import base64
from collections.abc import Mapping
from typing import Any

import httpx

from octop_harness.media.errors import MediaGenerationError
from octop_harness.media.http import BearerJsonMediaProvider, detect_media, provider_payload_error
from octop_harness.media.models import (
    ImageGenerationRequest,
    MediaCapabilities,
    MediaJobUpdate,
    MediaSubmission,
    ProviderTask,
    RemoteArtifact,
    VideoGenerationRequest,
)


class OpenAIImagesMediaProvider(BearerJsonMediaProvider):
    """Call OpenAI Images endpoints; this protocol does not support video."""

    provider_id = "openai_images"
    capabilities = MediaCapabilities(video_generation=False, image_references=True)

    async def _submit_image(
        self,
        client: httpx.AsyncClient,
        request: ImageGenerationRequest,
    ) -> MediaSubmission:
        body: dict[str, Any] = {
            "model": self.image_model,
            "prompt": request.prompt,
            "n": request.count,
            "output_format": "png",
        }
        if request.size:
            body["size"] = request.size
        if len(request.reference_images) > 16:
            raise MediaGenerationError("OpenAI accepts at most 16 reference images", code="invalid_request")
        if request.reference_images:
            field = "image[]" if len(request.reference_images) > 1 else "image"
            files = []
            for index, reference in enumerate(request.reference_images):
                data, media_type, extension = await self._reference_image(client, reference)
                files.append((field, (f"reference-{index}.{extension}", data, media_type)))
            payload = await self._request_json(
                client, "POST", "/images/edits", data={key: str(value) for key, value in body.items()}, files=files
            )
        else:
            payload = await self._request_json(client, "POST", "/images/generations", json=body)
        return MediaSubmission(artifacts=_image_artifacts(payload))

    async def _reference_image(self, client: httpx.AsyncClient, reference: str) -> tuple[bytes, str, str]:
        if reference.startswith("data:"):
            header, separator, encoded = reference.partition(",")
            try:
                if not separator or not header.endswith(";base64"):
                    raise ValueError("expected a base64 data URL")
                data = base64.b64decode(encoded, validate=True)
            except ValueError as exc:
                raise MediaGenerationError("Invalid reference image data URL", code="invalid_request") from exc
        else:
            data = await self._download(client, reference)
        media_type, extension = detect_media(data, fallback_type="application/octet-stream", fallback_extension="bin")
        if media_type not in {"image/png", "image/jpeg", "image/webp"}:
            raise MediaGenerationError("OpenAI reference images must be PNG, JPEG or WebP", code="invalid_request")
        return data, media_type, extension

    async def _submit_video(self, client: httpx.AsyncClient, request: VideoGenerationRequest) -> MediaSubmission:
        raise MediaGenerationError("OpenAI Images does not support video generation", code="unsupported_capability")

    async def _poll_task(self, client: httpx.AsyncClient, task: ProviderTask) -> MediaJobUpdate:
        raise MediaGenerationError(
            "OpenAI Images returns synchronous results, not tasks", code="unsupported_capability"
        )


def _image_artifacts(payload: Mapping[str, Any]) -> tuple[RemoteArtifact, ...]:
    if payload.get("error"):
        raise provider_payload_error(payload["error"], fallback="OpenAI image generation failed")
    rows = payload.get("data")
    if not isinstance(rows, list) or not rows:
        raise MediaGenerationError("OpenAI image generation returned no images", code="provider_response_invalid")
    artifacts: list[RemoteArtifact] = []
    for row in rows:
        if not isinstance(row, Mapping):
            continue
        encoded = row.get("b64_json")
        if isinstance(encoded, str) and encoded:
            try:
                data = base64.b64decode(encoded, validate=True)
            except ValueError as exc:
                raise MediaGenerationError(
                    "OpenAI returned invalid base64 image data", code="provider_response_invalid"
                ) from exc
            artifacts.append(RemoteArtifact(data=data, media_type="image/png", extension="png"))
            continue
        url = row.get("url")
        if isinstance(url, str) and url:
            artifacts.append(RemoteArtifact(url=url, media_type="image/png", extension="png"))
    if not artifacts:
        raise MediaGenerationError(
            "OpenAI image generation returned no usable images", code="provider_response_invalid"
        )
    return tuple(artifacts)


__all__ = ["OpenAIImagesMediaProvider"]
