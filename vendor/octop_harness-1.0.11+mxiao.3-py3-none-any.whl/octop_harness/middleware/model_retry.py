"""Preserve upstream retry policy and identify legacy synthetic error replies."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

from langchain.agents.middleware import ModelRequest, ModelResponse
from langchain.agents.middleware import ModelRetryMiddleware as BaseModelRetryMiddleware
from langchain_core.messages import AIMessage


def _validate_response(response: ModelResponse[Any]) -> ModelResponse[Any]:
    """Reject incomplete provider replies inside the retry budget."""
    for message in response.result:
        if not isinstance(message, AIMessage):
            continue
        metadata = message.response_metadata
        if metadata.get("finish_reason") == "error" or metadata.get("stop_reason") == "error":
            raise ValueError("Model response ended with an error")
        if (
            message.tool_calls
            or message.invalid_tool_calls
            or message.text.strip()
            or message.additional_kwargs.get("refusal")
            or message.additional_kwargs.get("audio")
            or metadata.get("stop_reason") == "refusal"
        ):
            return response
        if isinstance(message.content, list) and any(
            isinstance(block, dict)
            and block.get("type") in {"image", "image_url", "audio", "video", "file", "refusal"}
            and any(value for key, value in block.items() if key != "type")
            for block in message.content
        ):
            return response
    if response.structured_response is not None:
        return response
    raise ValueError("Model returned no usable response")


class ModelRetryMiddleware(BaseModelRetryMiddleware):
    """Retain provenance when an external caller explicitly requests ``continue``.

    Both sync and async retry exhaustion share this upstream formatting hook.
    HarnessAgent itself uses ``on_failure="error"`` and never emits this reply.
    """

    def wrap_model_call(
        self,
        request: ModelRequest[Any],
        handler: Callable[[ModelRequest[Any]], ModelResponse[Any]],
    ) -> ModelResponse[Any] | AIMessage:
        def checked(current: ModelRequest[Any]) -> ModelResponse[Any]:
            return _validate_response(handler(current))

        return super().wrap_model_call(request, checked)

    async def awrap_model_call(
        self,
        request: ModelRequest[Any],
        handler: Callable[[ModelRequest[Any]], Awaitable[ModelResponse[Any]]],
    ) -> ModelResponse[Any] | AIMessage:
        async def checked(current: ModelRequest[Any]) -> ModelResponse[Any]:
            return _validate_response(await handler(current))

        return await super().awrap_model_call(request, checked)

    @staticmethod
    def _format_failure_message(exc: Exception, attempts_made: int) -> AIMessage:
        message = BaseModelRetryMiddleware._format_failure_message(exc, attempts_made)
        message.response_metadata["octop_runtime_error"] = True
        return message
